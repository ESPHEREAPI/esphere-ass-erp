package zen.sin.bio.orassbio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrassbioApplicationTests {

	@Test
	void contextLoads() {
	}

}
