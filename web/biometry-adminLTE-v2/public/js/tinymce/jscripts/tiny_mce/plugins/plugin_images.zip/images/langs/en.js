tinyMCE.addI18n('en.images',{
	desc : 'Upload and insert picture'
});