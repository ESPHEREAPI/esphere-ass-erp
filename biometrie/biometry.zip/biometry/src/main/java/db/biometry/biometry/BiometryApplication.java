package db.biometry.biometry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiometryApplication {

	public static void main(String[] args) {
		SpringApplication.run(BiometryApplication.class, args);
	}

}
