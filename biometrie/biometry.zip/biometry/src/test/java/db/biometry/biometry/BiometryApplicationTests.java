package db.biometry.biometry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiometryApplicationTests {

	@Test
	void contextLoads() {
	}

}
